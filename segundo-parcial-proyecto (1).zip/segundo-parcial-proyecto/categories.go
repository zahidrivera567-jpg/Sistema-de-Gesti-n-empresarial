package main

import (
	"fmt"
	"strings"
)

func loadCategories() {
	rows, err := db.Query(
		"SELECT id, nombre FROM categorias ORDER BY id ASC",
	)
	if err != nil {
		panic(err)
	}
	defer rows.Close()

	categories = nil

	for rows.Next() {
		var c Category
		err := rows.Scan(&c.ID, &c.Name)
		if err != nil {
			panic(err)
		}
		categories = append(categories, c)
	}
}

func createCategory() {
	fmt.Print("Nombre Categoria: ")
	name := readString()

	if name == "" {
		fmt.Println("El nombre de la categoria no puede estar vacío.")
		return
	}

	_, err := db.Exec(
		"INSERT INTO categorias (nombre) VALUES (?)",
		name,
	)

	if err != nil {
		// Error por valor duplicado (UNIQUE)
		if strings.Contains(err.Error(), "1062") {
			fmt.Println("La categoria ya existe.")
			return
		}
		panic(err)
	}

	fmt.Println("Categoria creada correctamente.")
}

func listCategories() {
	loadCategories()

	for _, c := range categories {
		fmt.Printf("ID:%d - %s\n", c.ID, c.Name)
	}
}
