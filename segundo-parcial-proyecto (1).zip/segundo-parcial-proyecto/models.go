package main

import "time"

type Category struct {
	ID   int
	Name string
}

type Supplier struct {
	ID    int
	Name  string
	Email string
	Phone string
}

type Product struct {
	ID       int
	Name     string
	Price    float64
	Stock    int
	Category Category
	Supplier Supplier
}

type Sale struct {
	ID    int
	Date  time.Time
	Total float64
}

type SaleDetail struct {
	ID        int
	SaleID    int
	Product   Product
	Quantity  int
	UnitPrice float64
}
