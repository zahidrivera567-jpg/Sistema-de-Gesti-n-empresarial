package main

func main() {
	conectarBD() // ← conexión a la base de datos
	showMenu()   // ← tu menú
}
