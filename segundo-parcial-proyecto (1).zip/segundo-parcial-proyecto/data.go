package main

import (
	"database/sql"
	"fmt"

	_ "github.com/go-sql-driver/mysql"
)

var db *sql.DB

var categories []Category
var suppliers []Supplier
var products []Product
var sales []Sale

func conectarBD() {
	var err error

	dsn := "root:root@tcp(localhost:3306)/gestion_libros?parseTime=true"

	db, err = sql.Open("mysql", dsn)
	if err != nil {
		panic(err)
	}

	if err = db.Ping(); err != nil {
		panic(err)
	}

	fmt.Println("✅ Conectado a MySQL correctamente")
}
