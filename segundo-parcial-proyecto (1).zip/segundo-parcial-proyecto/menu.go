package main

import "fmt"

func showMenu() {
	for {
		fmt.Println("\n=== SISTEMA DE GESTION DE INVENTARIO ===")
		fmt.Println("1. Crear Categoria")
		fmt.Println("2. Listar Categorias")
		fmt.Println("3. Crear Proveedor")
		fmt.Println("4. Crear Producto")
		fmt.Println("5. Listar Productos")
		fmt.Println("6. Modificar Stock de Producto")
		fmt.Println("7. Registrar Venta")
		fmt.Println("8. Listar Ventas")
		fmt.Println("0. Salir")
		fmt.Print("Seleccione una opcion: ")

		opcion := readInt()

		switch opcion {
		case 1:
			createCategory()
		case 2:
			listCategories()
		case 3:
			createSupplier()
		case 4:
			createProduct()
		case 5:
			listProducts()
		case 6:
			updateProductStock()
		case 7:
			createSale()
		case 8:
			listSales()
		case 0:
			fmt.Println("Saliendo del sistema...")
			return
		default:
			fmt.Println("Opcion inválida.")
		}
	}
}
