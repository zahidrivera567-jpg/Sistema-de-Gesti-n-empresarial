package main

import "fmt"

// Cargar productos desde la BD
func loadProducts() {
	rows, err := db.Query(`
		SELECT p.id, p.nombre, p.precio, p.stock,
		       c.id, c.nombre,
		       pr.id, pr.nombre
		FROM productos p
		LEFT JOIN categorias c ON p.categoria_id = c.id
		LEFT JOIN proveedores pr ON p.proveedor_id = pr.id
		ORDER BY p.id ASC
	`)
	if err != nil {
		panic(err)
	}
	defer rows.Close()

	products = nil

	for rows.Next() {
		var p Product
		var cat Category
		var sup Supplier

		err := rows.Scan(
			&p.ID, &p.Name, &p.Price, &p.Stock,
			&cat.ID, &cat.Name,
			&sup.ID, &sup.Name,
		)
		if err != nil {
			panic(err)
		}

		p.Category = cat
		p.Supplier = sup
		products = append(products, p)
	}
}

// Crear producto en MySQL
func createProduct() {
	fmt.Print("Nombre Producto: ")
	name := readString()
	fmt.Print("Precio: ")
	price := readFloat()
	fmt.Print("Stock Inicial: ")
	stock := readInt()

	fmt.Println("Seleccione Categoria por ID:")
	listCategories()
	catID := readInt()

	fmt.Println("Seleccione Proveedor por ID:")
	listSuppliers()
	supID := readInt()

	if name == "" {
		fmt.Println("El nombre del producto no puede estar vacío.")
		return
	}

	result, err := db.Exec(
		`INSERT INTO productos 
		(nombre, precio, stock, categoria_id, proveedor_id)
		VALUES (?, ?, ?, ?, ?)`,
		name, price, stock, catID, supID,
	)
	if err != nil {
		panic(err)
	}

	id, _ := result.LastInsertId()
	fmt.Printf("Producto creado con ID %d.\n", id)
}

// Listar productos
func listProducts() {
	loadProducts()

	fmt.Println("\n--- LISTA DE PRODUCTOS ---")
	for _, p := range products {
		fmt.Printf(
			"ID:%d | %s | Precio: %.2f | Stock: %d | Categoria:%s | Proveedor:%s\n",
			p.ID, p.Name, p.Price, p.Stock,
			p.Category.Name, p.Supplier.Name,
		)
	}
}

// Modificar stock en MySQL
func updateProductStock() {
	fmt.Print("Ingrese ID del producto: ")
	id := readInt()
	fmt.Print("Cantidad a agregar o quitar: ")
	amount := readInt()

	_, err := db.Exec(
		"UPDATE productos SET stock = stock + ? WHERE id = ?",
		amount, id,
	)
	if err != nil {
		panic(err)
	}

	fmt.Println("Stock actualizado correctamente.")
}
