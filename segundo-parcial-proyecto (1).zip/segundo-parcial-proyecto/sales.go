package main

import (
	"fmt"
	"time"
)

// Registrar venta en MySQL
func createSale() {
	fmt.Println("Seleccione Producto por ID:")
	listProducts()
	prodID := readInt()

	fmt.Print("Cantidad: ")
	quantity := readInt()

	var price float64
	var stock int

	err := db.QueryRow(
		"SELECT precio, stock FROM productos WHERE id = ?",
		prodID,
	).Scan(&price, &stock)

	if err != nil {
		fmt.Println("Producto no encontrado.")
		return
	}

	if quantity > stock {
		fmt.Println("Stock insuficiente.")
		return
	}

	total := price * float64(quantity)

	result, err := db.Exec(
		"INSERT INTO ventas (total) VALUES (?)",
		total,
	)
	if err != nil {
		panic(err)
	}

	ventaID, _ := result.LastInsertId()

	_, err = db.Exec(
		`INSERT INTO detalle_ventas 
		(venta_id, producto_id, cantidad, precio_unitario)
		VALUES (?, ?, ?, ?)`,
		ventaID, prodID, quantity, price,
	)
	if err != nil {
		panic(err)
	}

	_, err = db.Exec(
		"UPDATE productos SET stock = stock - ? WHERE id = ?",
		quantity, prodID,
	)
	if err != nil {
		panic(err)
	}

	fmt.Println("Venta registrada correctamente.")
}

func listSales() {
	rows, err := db.Query(`
		SELECT v.id, v.fecha, p.nombre, d.cantidad, d.precio_unitario, v.total
		FROM ventas v
		JOIN detalle_ventas d ON v.id = d.venta_id
		JOIN productos p ON d.producto_id = p.id
		ORDER BY v.id ASC
	`)
	if err != nil {
		panic(err)
	}
	defer rows.Close()

	fmt.Println("\n--- LISTA DE VENTAS ---")

	for rows.Next() {
		var (
			ventaID  int
			fecha    time.Time
			prodName string
			cant     int
			price    float64
			total    float64
		)

		err := rows.Scan(&ventaID, &fecha, &prodName, &cant, &price, &total)
		if err != nil {
			panic(err)
		}

		fmt.Printf(
			"Venta:%d | Fecha:%s | Producto:%s | Cant:%d | Total: %.2f\n",
			ventaID,
			fecha.Format("02/01/2006 15:04"),
			prodName,
			cant,
			total,
		)
	}
}
