package main

import "fmt"

// Cargar proveedores desde la BD
func loadSuppliers() {
	rows, err := db.Query(
		"SELECT id, nombre, correo, telefono FROM proveedores ORDER BY id ASC",
	)
	if err != nil {
		panic(err)
	}
	defer rows.Close()

	suppliers = nil

	for rows.Next() {
		var s Supplier
		err := rows.Scan(&s.ID, &s.Name, &s.Email, &s.Phone)
		if err != nil {
			panic(err)
		}
		suppliers = append(suppliers, s)
	}
}

// Crear proveedor en MySQL
func createSupplier() {
	fmt.Print("Nombre: ")
	name := readString()
	fmt.Print("Correo: ")
	email := readString()
	fmt.Print("Telefono: ")
	phone := readString()

	if name == "" {
		fmt.Println("El nombre del proveedor no puede estar vacío.")
		return
	}

	result, err := db.Exec(
		"INSERT INTO proveedores (nombre, correo, telefono) VALUES (?, ?, ?)",
		name, email, phone,
	)
	if err != nil {
		panic(err)
	}

	id, _ := result.LastInsertId()
	suppliers = append(suppliers, Supplier{
		ID:    int(id),
		Name:  name,
		Email: email,
		Phone: phone,
	})

	fmt.Println("Proveedor creado.")
}

// Listar proveedores
func listSuppliers() {
	loadSuppliers()

	for _, s := range suppliers {
		fmt.Printf(
			"ID:%d - %s | Email: %s | Tel: %s\n",
			s.ID, s.Name, s.Email, s.Phone,
		)
	}
}
