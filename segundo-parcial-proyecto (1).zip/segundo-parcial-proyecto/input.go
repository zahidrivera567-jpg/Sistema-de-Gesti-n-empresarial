package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

var reader = bufio.NewReader(os.Stdin)

func readString() string {
	input, _ := reader.ReadString('\n')
	return strings.TrimSpace(input)
}

func readInt() int {
	for {
		fmt.Print("")
		input, _ := reader.ReadString('\n')
		input = strings.TrimSpace(input)

		num, err := strconv.Atoi(input)
		if err == nil {
			return num
		}
		fmt.Println("Ingrese un número válido.")
	}
}

func readFloat() float64 {
	for {
		fmt.Print("")
		input, _ := reader.ReadString('\n')
		input = strings.TrimSpace(input)

		num, err := strconv.ParseFloat(input, 64)
		if err == nil {
			return num
		}
		fmt.Println("Ingrese un número válido.")
	}
}
